import java.util.Scanner;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class JavaStockProgram {
    static String[][] stocks;
    static ArrayList<String> history = new ArrayList<>();
    static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int option;

        do {
            printMenu();
            System.out.print("Choose an option: ");
            option = sc.nextInt();

            switch (option) {
                case 1 -> setupStock(sc);
                case 2 -> viewStock();
                case 3 -> insertProduct(sc);
                case 4 -> updateProduct(sc);
                case 5 -> deleteProduct(sc);
                case 6 -> viewHistory();
                case 7 -> System.out.println("👋 Exiting the program. Goodbye!");
                default -> System.out.println("⚠️ Invalid option. Please try again.");
            }

            if (option != 7) {
                System.out.print("\nPress Enter to continue...");
                sc.nextLine(); sc.nextLine(); // Wait for user input
                clearScreen(); // Optional: clears console
            }

        } while (option != 7);

        sc.close();
    }

    // ========== MENU ==========
    static void printMenu() {
        System.out.println("\n===============================");
        System.out.println("     📦 Java Stock System");
        System.out.println("===============================");
        System.out.println("1. Set up Stock");
        System.out.println("2. View Stock");
        System.out.println("3. Insert Product");
        System.out.println("4. Update Product");
        System.out.println("5. Delete Product");
        System.out.println("6. View History");
        System.out.println("7. Exit");
        System.out.println("===============================");
    }

    // ========== OPTION 1 ==========
    static void setupStock(Scanner sc) {
        System.out.print("\nEnter number of Stocks: ");
        int numStocks = sc.nextInt();
        stocks = new String[numStocks][];

        for (int i = 0; i < numStocks; i++) {
            System.out.print("→ Number of catalogues in Stock [" + (i + 1) + "]: ");
            int numCatalogues = sc.nextInt();
            stocks[i] = new String[numCatalogues];
            for (int j = 0; j < numCatalogues; j++) {
                stocks[i][j] = "EMPTY";
            }
        }

        System.out.println("\n✅ Stock setup complete.");
        viewStock();
    }

    // ========== OPTION 2 ==========
    static void viewStock() {
        if (!isStockInitialized()) return;

        System.out.println("\n📋 Current Stock Status:");
        for (int i = 0; i < stocks.length; i++) {
            System.out.print("Stock [" + (i + 1) + "]: ");
            for (int j = 0; j < stocks[i].length; j++) {
                System.out.print("[" + (j + 1) + " - " + stocks[i][j] + "] ");
            }
            System.out.println();
        }
    }

    // ========== OPTION 3 ==========
    static void insertProduct(Scanner sc) {
        if (!isStockInitialized()) return;

        int s = getInput(sc, "Stock number: ") - 1;
        int c = getInput(sc, "Catalogue number: ") - 1;
        sc.nextLine(); // flush

        if (!isValidSlot(s, c)) return;

        if (!stocks[s][c].equals("EMPTY")) {
            System.out.println("⚠️ This slot is already occupied.");
            return;
        }

        System.out.print("Product name to insert: ");
        String name = sc.nextLine();
        stocks[s][c] = name;
        String timestamp = LocalDateTime.now().format(formatter);
        history.add(timestamp + " | 🟢 Inserted '" + name + "' into Stock[" + (s + 1) + "] Catalogue[" + (c + 1) + "]");
        System.out.println("✅ Product inserted.");
    }

    // ========== OPTION 4 ==========
    static void updateProduct(Scanner sc) {
        if (!isStockInitialized()) return;

        int s = getInput(sc, "Stock number: ") - 1;
        int c = getInput(sc, "Catalogue number: ") - 1;
        sc.nextLine(); // flush

        if (!isValidSlot(s, c)) return;

        System.out.print("New product name: ");
        String name = sc.nextLine();
        String timestamp = LocalDateTime.now().format(formatter);
        history.add(timestamp + " | 🟡 Updated Stock[" + (s + 1) + "] Catalogue[" + (c + 1) + "] to '" + name + "'");
        stocks[s][c] = name;
        System.out.println("🔄 Product updated.");
    }

    // ========== OPTION 5 ==========
    static void deleteProduct(Scanner sc) {
        if (!isStockInitialized()) return;

        int s = getInput(sc, "Stock number: ") - 1;
        int c = getInput(sc, "Catalogue number: ") - 1;

        if (!isValidSlot(s, c)) return;

        String product = stocks[s][c];
        String timestamp = LocalDateTime.now().format(formatter);
        history.add(timestamp + " | 🔴 Deleted '" + product + "' from Stock[" + (s + 1) + "] Catalogue[" + (c + 1) + "]");
        stocks[s][c] = "EMPTY";
        System.out.println("❌ Product deleted.");
    }

    // ========== OPTION 6 ==========
    static void viewHistory() {
        System.out.println("\n📜 Action History:");
        if (history.isEmpty()) {
            System.out.println("No actions recorded yet.");
        } else {
            System.out.printf("%-22s | %s\n", "📅 Date & Time", "📝 Action");
            System.out.println("------------------------------------------------------------");
            for (String h : history) {
                String[] parts = h.split(" \\| ", 2);
                if (parts.length == 2) {
                    System.out.printf("%-22s | %s\n", parts[0], parts[1]);
                } else {
                    System.out.println(h); // fallback
                }
            }
        }
    }

    // ========== HELPERS ==========
    static boolean isStockInitialized() {
        if (stocks == null) {
            System.out.println("⚠️ Please set up stock first.");
            return false;
        }
        return true;
    }

    static boolean isValidSlot(int s, int c) {
        if (s < 0 || s >= stocks.length || c < 0 || c >= stocks[s].length) {
            System.out.println("⚠️ Invalid stock/catalogue number.");
            return false;
        }
        return true;
    }

    static int getInput(Scanner sc, String message) {
        System.out.print(message);
        return sc.nextInt();
    }

    static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}
